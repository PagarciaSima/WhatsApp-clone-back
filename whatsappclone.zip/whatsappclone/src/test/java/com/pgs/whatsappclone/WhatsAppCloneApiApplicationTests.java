package com.pgs.whatsappclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhatsAppCloneApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
